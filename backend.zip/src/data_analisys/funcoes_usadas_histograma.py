


import geopy.distance # Usado para calcularDistancia

import numpy as np


# Função separa dados do json
def split_satelites_customers(Features):
    Satelites = list()
    Customers = list()
    
    for feature in Features:
        if feature["properties"]["type"] == "satellite":
            data = {"name": feature["properties"]["name"], "coordinates": feature["geometry"]["coordinates"]}
            Satelites.append(data)
        if feature["properties"]["type"] == "costumer":
            data = {"coordinates": feature["geometry"]["coordinates"]}
            Customers.append(data)
    return Satelites, Customers


# Função que calcula distancia entre dois pontos
def calc_Dist_KM(local1, local2, fatorCircuito=1):
    
    coords_1 = (local1[0], local1[1])
    coords_2 = (local2[0], local2[1])
            
    return geopy.distance.geodesic(coords_1, coords_2).km * fatorCircuito
    
def get_smallDiscante_from_satelite_to_Customers(Satelites, Customers, fatorCircuito=1):
    Distances = list()
    for custome in Customers:
        menor_d = -1
        for satelite in Satelites:
            d = calc_Dist_KM(custome["coordinates"], satelite["coordinates"], fatorCircuito)
            #d = 1
            if menor_d == -1:
                menor_d = d
            if d < menor_d:
                menor_d = d
        Distances.append(menor_d)
    return Distances
    
def get_histogram_from_distances(Distances):
    hist = list()
    min_ = int(min(Distances))
    max_ = int(max(Distances))+1
    
    step = 0.5
    for x in np.arange(min_, max_,step):
        #count = sum(map(lambda x_ : (x_ >= x and x_ < x+step), Distances))
        count = sum([1 for d in Distances if (d >= x and d < x+step)])
        data = {"x": x, "y": count}
        hist.append(data)
    return hist