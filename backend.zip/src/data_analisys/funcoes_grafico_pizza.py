



def calc_pie_chart_date_customers_vs_satelites(Features, satelities=[]):
    
    demand = sum([ f["properties"]["demand"] for f in Features if f["properties"]["type"] == "costumer"])
    def verifica(f, names):
        if (f["properties"]["type"] == "satellite"):
            if f["properties"]["name"] in names:
                return True
        return False
    if satelities==[]:
        capacity = sum([ f["properties"]["capacity"] for f in Features if f["properties"]["type"] == "satellite"])
    else:
        names = [a['name'] for a in satelities]
        capacity = sum([ f["properties"]["capacity"] for f in Features if verifica(f, names)])
    
    slack_in_demand = max([0,capacity - demand])
    excess_demand = max([0,demand - capacity])
    
    if capacity <= 0:
        return {"demand":0, "slack_in_demand": 1, "excess_demand": 0}
    
    if excess_demand == 0:
        d = demand/capacity
        s = slack_in_demand / capacity
        e = 0
        return {"demand":d, "slack_in_demand": s, "excess_demand": e}
    else:
        d = capacity / demand
        s = 0
        e = excess_demand/demand
        return {"demand":d, "slack_in_demand": s, "excess_demand": e}
    
    