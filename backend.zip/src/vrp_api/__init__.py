from .Methods import Heuristica
