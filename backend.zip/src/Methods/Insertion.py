
try:
    from insercao_lib import algoritmo
except Exception:
    from .insercao_lib import algoritmo

Insertion = algoritmo