import numpy as np

class algoritmo:
    def calcCost(self, route):
        return self.d[np.roll(route, 1), route].sum()
        
    def main(self, d, index_SAT, Vehicle, CUSTOMERS):
        self.d = d
        
        C_Indexs = [CUSTOMER["index_aID"] for CUSTOMER in CUSTOMERS]
        C_Packs = [CUSTOMER["dropsize"] for CUSTOMER in CUSTOMERS]
        
        routes = []
        
        route = [index_SAT, index_SAT]
        pacotes = 0
        
        
        while len(C_Indexs)>0:
            
            bestC = -1
            bestPos = -1
            bestidxCi = -1
            bestCost = -1
            
            #print(route)
            #for pos in range(1, len(route)):
            #    print(pos, route[:pos], route[pos:])
            #    npRotas = np.zeros(shape=(len(C_Indexs), len(route)+1))
            #    CILIST = np.reshape(C_Indexs, (len(C_Indexs), 1))
            #    npRotas[:, :pos] = route[:pos]
            #    npRotas[:, pos+1:] = route[pos:]
            #    npRotas[:, pos] = CILIST[:, 0]
            #    print(npRotas)
            
            
            for idxCi, ci in enumerate(C_Indexs):
                if (pacotes + C_Packs[idxCi] <= Vehicle["capacity"]):
                    for pos in range(1, len(route)):
                        if self.d[route[pos-1], ci] >= 0 and self.d[ci, route[pos]] >= 0:
                            #print(route, route[pos-1], route[pos], ci, self.d[route[pos-1], ci], self.d[ci, route[pos]])
                            newRoute = route.copy()
                            newRoute.insert(pos, ci)
                            cost = self.calcCost(newRoute)
                            if (cost < bestCost or bestCost == -1):
                                bestCost = cost
                                bestC = ci
                                bestPos = pos
                                bestidxCi = idxCi
            
            if bestC != -1:
                route.insert(bestPos, bestC)
                pacotes += C_Packs[bestidxCi]
                #print(bestC, bestPos, route, self.calcCost(route), pacotes)
                del C_Indexs[bestidxCi]
                del C_Packs[bestidxCi]
            else:
                routes.append({"route": route, "pacotes": pacotes, "cost": self.calcCost(route)})
                
                route = [index_SAT, index_SAT]
                pacotes = 0
                bestCost = -1
        
        if len(route)>2:# Rota a encerrar
            routes.append({"route": route, "pacotes": pacotes, "cost": bestCost})
                
            route = [index_SAT, index_SAT]
            pacotes = 0
            bestCost = -1
        
        self.routes = routes