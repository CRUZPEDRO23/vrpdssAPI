
import numpy as np

try:
    from .ClarkeANDWright import ClarkeANDWright
    from .Insertion import Insertion
except Exception:
    from ClarkeANDWright import ClarkeANDWright
    from Insertion import Insertion



# Separa clientes mais proximos para os satelites / considera limites de distancia do satelite também

#SAT :: STR
#index_SAT :: int
#Vehicle :: OBJECT <type, capacity, RangeLimit_KM>
#CUSTOMERS :: LIST<CUSTOMER>
#CUSTOMER :: OBJECT<name, address, index_aID, shID, addressLatLng, dropsize>

np.random.seed(seed=None)

nC = 1000
d = np.zeros(shape=(nC+1, nC+1))-1

d[nC, :] = 1
d[:, nC] = 1

print(np.random.randint(1, 100))

step = 500
for v in range(0, nC, step):
    d[v:v+step,v:v+step] = 2#np.random.randint(1, 100)

print(d)

SAT = "SAT_1"
index_SAT = nC

CUSTOMER = lambda name, address, index_aID, shID, addressLatLng, dropsize: {"name":name, "address":address, "index_aID":index_aID, "shID":shID, "addressLatLng":addressLatLng, "dropsize":dropsize}
CUSTOMERS = [CUSTOMER(f"cID_{i}", f"aID_{i}", i, f"shID_{i}", {}, 1) for i in range(nC)]

Vehicle = {"type": "CargoBike", "capacity": 10, "RangeLimit_KM": 1}
vehiclesCapacity = Vehicle["capacity"]



import time

VRP = ClarkeANDWright()
t = time.time()
VRP.main(d, index_SAT, Vehicle, CUSTOMERS,opt_exec = False)
for r in VRP.routes:
    print(r)
print("Executado em", time.time()-t)
    
def run(Method):
    VRP = Method()
    t = time.time()
    VRP.main(d, index_SAT, Vehicle, CUSTOMERS)
    for r in VRP.routes:
        print(r)
    print("Executado em", time.time()-t)

run(ClarkeANDWright)
run(Insertion)

