import numpy as np

class ClarkeANDWright:
    
    def createInitialRoutes(self, C_Indexs):
        """
        Cada cliente i vai pra uma nova rota r = (0, i, 0)
        que vai do deposito ao cliente e retorna ao deposito

        :param C_Indexs:
        :return: retorn a lista com as n rotas
        """
        routes = []  # solucao
        for i in C_Indexs:
            routes.append([i]) # nao adicionando o deposito para melhor manutencao do codigo
        return routes
        
    def computeSavingsList(self, index_SAT, C_Indexs):
        """
        savings_list = {};
        foreach i, j ∈ V - {0} do
            Sij = C(0, i) + C(0, j) - C(i, j);
            savings_list <- Si, j;
        sort_decreasing(savings_list);
        return savings_list;

        :index_SAT: indice do satelite, C_Indexs: indices dos clientes
        :return: lista de savings, ordenada por ordem decrescente de economia
        """
        list = []
        INDEXs = C_Indexs
        
        for idx_i, i in enumerate(INDEXs):
            for idx_j, j in enumerate(INDEXs):
                if i != j and self.d[i, j]>=0 and self.d[i, index_SAT]>=0 and self.d[index_SAT, j]>=0:
                    save = self.d[i, index_SAT] + self.d[index_SAT, j] - self.d[i, j] # sij = di0 + d0j − dij , for all i, j ≥ 1 and i != j;
                    list.append([(i, j), save])
                    
        

        list.sort(key=lambda x: x[1], reverse=True)  # ordena a lista de saves, decrescente
        return list
    def feasibleMerge(self, i, j, routes, vehiclesCapacity):
        """
        Para duas rotas (r e s) serem factiveis de fusao,
         i deve ser o ultimo cliente a ser visitado na sua rota r
         j deve ser o primeiro cliente a ser visitado na sua rota s
         < ou ao contrario >
        e se a soma das demandas dos clientes das duas rotas nao excede a capacidade maxima

        :param i:
        :param j:
        :param routes: lista de rotas
        :param graph: grafo
        :return:
        """
        r, s = [], [] # rota inicial e final
        for route in routes: # percorre cada rota
            if route[0] == j and route != r: # se a rota começar com j
                s = route # rota inicial eh agora, a rota q iniciou com j
            elif route[-1] == i and route != s: # se a rota termina com i
                r = route # a rota final agora eh a rota q termina com i

            if r and s: # se as rotas existem, ou seja, se existiu alguma rota q comecou com j e outra q terminou com i
                pacotes = self.C_Packs[r].sum()+self.C_Packs[s].sum()
                if pacotes <= vehiclesCapacity: # ele testa se o somatorio das demandas das duas rotas nao excede a capacidade maxima
                    return True # se nao exceder, entao SIM. as rotas podem ser unidas

        return False

    def mergeRoutes(self, i, j, routes):
        """
        Faz um merge entre as rotas r e s, sendo:
            r a rota que contem j: r = (0, ..., j, 0)
            s a rota que contem i: s = (0, i, ..., 0)

        :param i:
        :param j:
        :param routes:
        :return:
        """
        r, s = [], []
        
        for route in routes:
            if route[0] == j:
                s = route
            elif route[-1] == i:
                r = route
        
        routes.remove(r) # remove r
        routes.remove(s) # remove s
        routes.append(r + s)
        
    def calcCost(self, route):
        return self.d[np.roll(route, 1), route].sum()
        
    def main(self, d, index_SAT, Vehicle, CUSTOMERS, opt_exec = True):
        self.d = d
        
        C_Indexs = [CUSTOMER["cID"] for CUSTOMER in CUSTOMERS]
        self.C_Packs = np.array([CUSTOMER["dropsize"] for CUSTOMER in CUSTOMERS])
        
        vehiclesCapacity = Vehicle["capacity"]
        print("Calculando Economias")
        solution = (self.createInitialRoutes(C_Indexs)).copy() # cria rotas com as cidades apenas - passo 1
        listOfSaves = self.computeSavingsList(index_SAT,C_Indexs) # lista de economias - passo 2
        
        with open("foo.txt", "w") as f:
            f.write(str(listOfSaves))
            f.close()
        #print("listOfSaves", len(listOfSaves))
        if opt_exec:
            
            list_i = []
            list_j = []
            print("listOfSaves", len(listOfSaves))
            for idx_s, save in enumerate(listOfSaves): # passo 3
                i, j = save[0]
                #print(i,j, self.feasibleMerge(i, j, solution, vehiclesCapacity))
                if i not in list_i and j not in list_j:
                    if (self.feasibleMerge(i, j, solution, vehiclesCapacity)):
                        self.mergeRoutes(i, j, solution) # passo 5
                        list_i.append(i)
                        list_j.append(j)
        else:
            for idx_s, save in enumerate(listOfSaves): # passo 3
                i, j = save[0]
                #print(i,j, self.feasibleMerge(i, j, solution, vehiclesCapacity))
                if (self.feasibleMerge(i, j, solution, vehiclesCapacity)):
                    self.mergeRoutes(i, j, solution) # passo 5
        #print(solution)
        
        self.routes = [[index_SAT]+route+[index_SAT] for route in solution]
algoritmo = ClarkeANDWright
