
try:
    from clarke_and_wright_lib import algoritmo
except Exception:
    from .clarke_and_wright_lib import algoritmo


ClarkeANDWright = algoritmo
