Vehicle_Data = [
    {"type":"Bitruck", "id": 0, "capacidade":11500, "quantidade": "inf", "nome": "Bitruck", "data":{"variable_cost": 2.65, "fixed_cost": 1200, "averege_speed":60}}
    ]

warehouse_Data = [
    {"type": "warehouse", "id":0, "name": "cd", "coordinates": [-29.81714286,-51.20047619], "data":{}}
    ]
customer_Data = [
    {"type":"customer", "id": 1, "name": "customer1", "coordinates":[-30.03,-51.22], "data":{"demand": 1030, "stock": 5541, "tank_size": 5541,"service_time": 3600}},
    {"type":"customer", "id": 2, "name": "customer2", "coordinates":[-29.93,-51.16], "data":{"demand": 4948, "stock": 17100, "tank_size": 17100,"service_time": 3600}},
    {"type":"customer", "id": 3, "name": "customer3", "coordinates":[-30.05,-51.21], "data":{"demand": 1513, "stock": 9120, "tank_size": 9120,"service_time": 3600}},
    {"type":"customer", "id": 4, "name": "customer4", "coordinates":[-29.8,-51.87], "data":{"demand": 315, "stock": 3420, "tank_size": 3420,"service_time": 3600}},
    {"type":"customer", "id": 5, "name": "customer5", "coordinates":[-30.1,-51.25], "data":{"demand": 1214, "stock": 2867, "tank_size": 2867,"service_time": 3600}},
    {"type":"customer", "id": 6, "name": "customer6", "coordinates":[-29.46,-51.97], "data":{"demand": 2705, "stock": 26972, "tank_size": 26972,"service_time": 3600}},
    {"type":"customer", "id": 7, "name": "customer7", "coordinates":[-29.93,-51.18], "data":{"demand": 10010, "stock": 57000, "tank_size": 57000,"service_time": 3600}},
    {"type":"customer", "id": 8, "name": "customer8", "coordinates":[-29.78,-51.15], "data":{"demand": 2159, "stock": 22800, "tank_size": 22800,"service_time": 3600}},
    {"type":"customer", "id": 9, "name": "customer9", "coordinates":[-29.9,-51.18], "data":{"demand": 78, "stock": 3420, "tank_size": 3420,"service_time": 3600}},
    {"type":"customer", "id": 10, "name": "customer10", "coordinates":[-29.94,-50.99], "data":{"demand": 3059, "stock": 12882, "tank_size": 12882,"service_time": 3600}},
    {"type":"customer", "id": 11, "name": "customer11", "coordinates":[-29.7,-51.2], "data":{"demand": 49, "stock": 5700, "tank_size": 5700,"service_time": 3600}},
    {"type":"customer", "id": 12, "name": "customer12", "coordinates":[-29.71,-51.14], "data":{"demand": 41, "stock": 1254, "tank_size": 1254,"service_time": 3600}},
    {"type":"customer", "id": 13, "name": "customer13", "coordinates":[-29.67,-51.13], "data":{"demand": 4048, "stock": 11400, "tank_size": 11400,"service_time": 3600}},
    {"type":"customer", "id": 14, "name": "customer14", "coordinates":[-29.91,-51.2], "data":{"demand": 1588, "stock": 12540, "tank_size": 12540,"service_time": 3600}},
    {"type":"customer", "id": 15, "name": "customer15", "coordinates":[-29.95,-51.18], "data":{"demand": 696, "stock": 1847, "tank_size": 1847,"service_time": 3600}},
    {"type":"customer", "id": 16, "name": "customer16", "coordinates":[-29.69,-51.05], "data":{"demand": 1405, "stock": 6840, "tank_size": 6840,"service_time": 3600}},
    {"type":"customer", "id": 17, "name": "customer17", "coordinates":[-29.64,-50.78], "data":{"demand": 1362, "stock": 6042, "tank_size": 6042,"service_time": 3600}},
    {"type":"customer", "id": 18, "name": "customer18", "coordinates":[-29.57,-50.8], "data":{"demand": 768, "stock": 2789, "tank_size": 2789,"service_time": 3600}},
    {"type":"customer", "id": 19, "name": "customer19", "coordinates":[-29.96,-51.72], "data":{"demand": 1245, "stock": 17100, "tank_size": 17100,"service_time": 3600}},
    {"type":"customer", "id": 20, "name": "customer20", "coordinates":[-30.04,-51.21], "data":{"demand": 9449, "stock": 57969, "tank_size": 57969,"service_time": 3600}},
    {"type":"customer", "id": 21, "name": "customer21", "coordinates":[-29.51,-51.97], "data":{"demand": 855, "stock": 11400, "tank_size": 11400,"service_time": 3600}},
    {"type":"customer", "id": 22, "name": "customer22", "coordinates":[-29.59,-51.37], "data":{"demand": 249, "stock": 3876, "tank_size": 3876,"service_time": 3600}},
    {"type":"customer", "id": 23, "name": "customer23", "coordinates":[-29.89,-50.27], "data":{"demand": 1172, "stock": 5541, "tank_size": 5541,"service_time": 3600}},
    {"type":"customer", "id": 24, "name": "customer24", "coordinates":[-29.69,-51.24], "data":{"demand": 704, "stock": 4025, "tank_size": 4025,"service_time": 3600}},
    {"type":"customer", "id": 25, "name": "customer25", "coordinates":[-30.11,-51.31], "data":{"demand": 121, "stock": 2052, "tank_size": 2052,"service_time": 3600}},
    {"type":"customer", "id": 26, "name": "customer26", "coordinates":[-29.59,-51.16], "data":{"demand": 445, "stock": 3420, "tank_size": 3420,"service_time": 3600}},
    {"type":"customer", "id": 27, "name": "customer27", "coordinates":[-29.91,-51.15], "data":{"demand": 987, "stock": 3033, "tank_size": 3033,"service_time": 3600}},
    {"type":"customer", "id": 28, "name": "customer28", "coordinates":[-29.73,-51.16], "data":{"demand": 561, "stock": 2401, "tank_size": 2401,"service_time": 3600}},
    {"type":"customer", "id": 29, "name": "customer29", "coordinates":[-30.03,-51.22], "data":{"demand": 8820, "stock": 30780, "tank_size": 30780,"service_time": 3600}},
    {"type":"customer", "id": 30, "name": "customer30", "coordinates":[-29.7,-51.09], "data":{"demand": 82, "stock": 2291, "tank_size": 2291,"service_time": 3600}},
    {"type":"customer", "id": 31, "name": "customer31", "coordinates":[-29.94,-51.11], "data":{"demand": 102, "stock": 2000, "tank_size": 2000,"service_time": 3600}},
    {"type":"customer", "id": 32, "name": "customer32", "coordinates":[-29.61,-52.19], "data":{"demand": 1198, "stock": 3420, "tank_size": 3420,"service_time": 3600}},
    {"type":"customer", "id": 33, "name": "customer33", "coordinates":[-29.52,-50.78], "data":{"demand": 375, "stock": 5700, "tank_size": 5700,"service_time": 3600}},
    {"type":"customer", "id": 34, "name": "customer34", "coordinates":[-29.64,-51.01], "data":{"demand": 880, "stock": 9547, "tank_size": 9547,"service_time": 3600}},
    {"type":"customer", "id": 35, "name": "customer35", "coordinates":[-29.88,-51.19], "data":{"demand": 87, "stock": 5700, "tank_size": 5700,"service_time": 3600}},
    {"type":"customer", "id": 36, "name": "customer36", "coordinates":[-29.82,-50.52], "data":{"demand": 767, "stock": 6042, "tank_size": 6042,"service_time": 3600}},
    {"type":"customer", "id": 37, "name": "customer37", "coordinates":[-29.79,-51.17], "data":{"demand": 90, "stock": 3420, "tank_size": 3420,"service_time": 3600}},
    {"type":"customer", "id": 38, "name": "customer38", "coordinates":[-29.69,-51.48], "data":{"demand": 819, "stock": 3442, "tank_size": 3442,"service_time": 3600}},
    {"type":"customer", "id": 39, "name": "customer39", "coordinates":[-29.69,-51.13], "data":{"demand": 626, "stock": 5069, "tank_size": 5069,"service_time": 3600}},
    {"type":"customer", "id": 40, "name": "customer40", "coordinates":[-30.04,-51.15], "data":{"demand": 557, "stock": 3420, "tank_size": 3420,"service_time": 3600}},
    {"type":"customer", "id": 41, "name": "customer41", "coordinates":[-30.11,-51.11], "data":{"demand": 439, "stock": 5130, "tank_size": 5130,"service_time": 3600}},
    {"type":"customer", "id": 42, "name": "customer42", "coordinates":[-30.08,-51.05], "data":{"demand": 730, "stock": 2771, "tank_size": 2771,"service_time": 3600}}

]
