import geopy.distance # Usado para calcularDistancia
import numpy as np

from data import *

class instancia:
    def __init__(self,Vehicle_Data, warehouse_Data, customer_Data):
        self.Vehicle_Data = dict()
        for v in Vehicle_Data:
            self.Vehicle_Data[v["id"]] = v
        
        self.warehouse_Data = dict()
        for w in warehouse_Data:
            self.warehouse_Data[w["id"]] = w

        self.customer_Data = dict()
        for c in customer_Data:
            self.customer_Data[c["id"]] = c
        self.distance = dict()
        
class CVRP_algorithm(instancia):
    def insertionMethod(self, weights, functions):
        rotas = {}
        customers_visited = []
        rota_id = 0
        while 1: #Montando rotas
            truck_load = 0
            travel_time = 0
            rota = [self.warehouse_Data[0]["id"], self.warehouse_Data[0]["id"]]
            while 1:# Montanto uma rota
                id_melhor_C = -1 #Id do melhor cliente para inserir
                f_melhor_C = -1 #pontuacao do melhor cliente para inserir
                melhor_posicao = -1
                melhor_c = -1
                best_data = {}
                
                for c in self.customer_Data:
                    if c not in customers_visited and truck_load + self.customer_Data[c]["data"]["demand"] <= self.Vehicle_Data[0]["capacidade"] and travel_time <= 16: # para cada cliente não visitado
                        for posicao in range(1, len(rota)):
                            rota_ = self._insert(rota, self.customer_Data[c]["id"], posicao)

                            dados = self._evaluete(rota_, truck_load)
                            
                            value_function = self._f_objetivo(weights, functions, dados)
                            if id_melhor_C == -1 or value_function > f_melhor_C:
                                id_melhor_C = self.customer_Data[c]["id"]
                                f_melhor_C = value_function
                                melhor_posicao = posicao
                                melhor_c = c
                                best_data = dados
                if id_melhor_C != -1:
                    rota = self._insert(rota, id_melhor_C, melhor_posicao)
                    customers_visited.append(melhor_c)
                    truck_load += self.customer_Data[melhor_c]["data"]["demand"]
                    travel_time = best_data['travel_time']
                else:
                    break
            
            #rotas.append(rota)
            data = self._evaluete(rota, truck_load)
            rotas[str(rota_id)] = {'rota':rota, 'data':data}
            rota_id+=1
            #print(truck_load, rota, self._f_objetivo(weights, functions, self._evaluete(rota_, truck_load)))
            if len(customers_visited) == len(self.customer_Data):
                break
            
        return rotas
    def _insert(self, rota, id_, posicao):
        rota_ = rota[0:posicao]
        rota_.append(id_)
        rota_ += rota[posicao:]
        
        return rota_
    def _f_objetivo(self, weights, functions, dados):
        u = 0
        for tag in weights:
            u += weights[tag] * functions[tag](dados[tag])
        return u
    def _evaluete(self,rota_, truck_load):
        dados = {
            'cost': 1,
            'travel_time':1,
            'truck_load': 1
            }

        # Calcula distancia da Rota
        distance = 0
        for i in range(1, len(rota_)):
            if i == 1:
                coords_1 = (self.warehouse_Data[rota_[i-1]]["coordinates"][0], self.warehouse_Data[rota_[i-1]]["coordinates"][1])
                coords_2 = (self.customer_Data[rota_[i]]["coordinates"][0], self.customer_Data[rota_[i]]["coordinates"][1])
            elif i == len(rota_)-1:
                coords_1 = (self.customer_Data[rota_[i-1]]["coordinates"][0], self.customer_Data[rota_[i-1]]["coordinates"][1])
                coords_2 = (self.warehouse_Data[rota_[i]]["coordinates"][0], self.warehouse_Data[rota_[i]]["coordinates"][1])
            else:
                coords_1 = (self.customer_Data[rota_[i-1]]["coordinates"][0], self.customer_Data[rota_[i-1]]["coordinates"][1])
                coords_2 = (self.customer_Data[rota_[i]]["coordinates"][0], self.customer_Data[rota_[i]]["coordinates"][1])
            
            if (rota_[i-1], rota_[i]) not in self.distance:
                self.distance[(rota_[i-1], rota_[i])] = geopy.distance.geodesic(coords_1, coords_2).km
            distance += self.distance[(rota_[i-1], rota_[i])]
        dados['cost'] = distance * self.Vehicle_Data[0]["data"]["variable_cost"] + self.Vehicle_Data[0]["data"]["fixed_cost"]
        dados['truck_load'] = truck_load/self.Vehicle_Data[0]["capacidade"]
        dados['travel_time'] = distance / self.Vehicle_Data[0]['data']['averege_speed']

        return dados

                            
weights = {
    'cost': 1,
    'travel_time':1,
    'truck_load': 1
    }
functions = {
    'cost': lambda x: x**(1/2),
    'travel_time':lambda x: x/16 * 100,
    'truck_load': lambda x: x*100
    }

if __name__ == '__main__':
    VRP = CVRP_algorithm(Vehicle_Data, warehouse_Data, customer_Data)
    rotas = VRP.insertionMethod(weights, functions)
    for rota in rotas:
        print(rota, round(rotas[rota]['data']['cost'],2), round(rotas[rota]['data']['travel_time'],2) , round(rotas[rota]['data']['truck_load'],2), rotas[rota]['rota'])
    

    
