
try:
    from .Modelo import Modelo
except Exception:
    from Modelo import Modelo

class Insertion(Modelo):
    def __init__(self):
        pass