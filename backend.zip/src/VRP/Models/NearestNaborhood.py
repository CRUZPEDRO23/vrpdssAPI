#Armazém Osasco B2w 23°31'31.0"S 46°45'49.5"W -23.525285, -46.763742 R. Henry Ford, 643a - Pres. Altino, Osasco - SP, 06210-108
# Design of a two-echelon last-mile delivery model
try:
    from interface_Problema import interface_Problema
except Exception:
    from .interface_Problema import interface_Problema
from geopy.distance import geodesic

class NearestNaborhood(interface_Problema):
    def Rotas_SegundaCamada(self):
        
        rotas = []
        currentRoutes = {s: {'route': [s,s], "waitTime":{}, "camada":2, "ships":[], "address": {},"fromSat": s, "toSat": s, 'cost': 0, 'pacotes': 0, 'time': 0, "weight":0, "camada": 2} for s in self.S} # Inicia uma Rota por satelite
        
        remessasNaoRoteados = list(self.R.keys())
        getAddress = lambda shID: self.R[shID]["aID"] if shID not in self.S else shID
        getCustomer = lambda shID: self.R[shID]["cID"] if shID not in self.S else shID
        getLatLngSat = lambda sID: (self.S[sID]["lat"], self.S[sID]["lng"])
        getLatLng = lambda aID: (self.Enderecos[aID]["lat"], self.Enderecos[aID]["lng"]) if aID not in self.S else getLatLngSat(aID)
        
        while len(remessasNaoRoteados)>0:
            
            best_c = {s: -1 for s in self.S}
            best_address = {s: -1 for s in self.S}
            best_r = {s: -1 for s in self.S}
            
            best_cost = {s: -1 for s in self.S}
            best_pos = {s: -1 for s in self.S}
            
            best_satelite = -1
            add_time = {s: -1 for s in self.S} # Tempo da rota inserida
            
            for s in self.S:
                rota = currentRoutes[s]['route'].copy()
                
                pos = len(rota)-1
                
                shID_i = rota[-2]
                aID_i = getAddress(shID_i)
                
                shID_j = rota[-1]
                aID_j = getAddress(shID_j)
                
                for shID in remessasNaoRoteados:
                    cID = getCustomer(shID)
                    aID_R = getAddress(shID)
                
                    # Calc Dist
                    from_aID = getLatLngSat(aID_i) if aID_i in self.S else getLatLng(aID_i)
                    to_aID = getLatLng(aID_R)
                    
                    if aID_i not in self.d2_ij: self.d2_ij[aID_i] = dict()
                    if aID_R not in self.d2_ij[aID_i]: 
                        self.d2_ij[aID_i][aID_R] = geodesic(from_aID, to_aID).km 
                    
                    from_aID = getLatLng(aID_R)
                    to_aID = getLatLngSat(aID_j) if aID_j in self.S else getLatLng(aID_j)
                    
                    if aID_R not in self.d2_ij: self.d2_ij[aID_R] = dict()
                    if aID_j not in self.d2_ij[aID_R]: 
                        self.d2_ij[aID_R][aID_j] = geodesic(from_aID, to_aID).km 
                    
                    from_aID = getLatLngSat(aID_i) if aID_i in self.S else getLatLng(aID_i)
                    to_aID = getLatLngSat(aID_j) if aID_j in self.S else getLatLng(aID_j)
                    
                    if aID_i not in self.d2_ij: self.d2_ij[aID_i] = dict()
                    if aID_j not in self.d2_ij[aID_i]: 
                        self.d2_ij[aID_i][aID_j] = geodesic(from_aID, to_aID).km 
                        
                        
                    cost = currentRoutes[s]['cost'] + self.d2_ij[aID_i][aID_R] + self.d2_ij[aID_R][aID_j] - (self.d2_ij[aID_i][aID_j] if aID_i!=aID_j else 0)
                    
                    add_time[s] = (self.d2_ij[aID_i][aID_R] + self.d2_ij[aID_R][aID_j] - (self.d2_ij[aID_i][aID_j] if aID_i!=aID_j else 0)) / self.K2["veloc"] # Tempo de viajem
                    # Add tempo de parada se o endereço nao estiver na rota
                    add_time[s] += self.TempoParada if (aID_R not in currentRoutes[s]["address"]) else 0
                    
                    if (best_cost[s] == -1 or best_cost[s] > cost) and (currentRoutes[s]['pacotes']+self.R[shID]["Dropsize"] <= self.K2["capacidade"])  and (currentRoutes[s]['weight']+self.R[shID]["weight"] <= self.K2["capacidade_Weigth"]):
                        best_cost[s] = cost
                        best_address[s] = aID_R
                        best_c[s] = cID
                        best_r[s] = shID
                        best_pos[s] = pos

                        if all([ (cost<=best_cost[s_] or best_cost[s_] == -1) for s_ in self.S if s_ != s]):
                            best_satelite = s
                        
            
            # Verificar Rotas Completas
            bool_PermitirInsercao = True
            for s in self.S:
                if best_cost[s] == -1:# Sem entrada de clientes disponivel
                    if len(currentRoutes[s]['route']) > 2:
                        rotas.append(currentRoutes[s].copy())#"costumers": {}, 
                        currentRoutes[s] = {'route': [s,s], "waitTime":{}, "camada":2, "ships":[], "address": {},"fromSat": s, "toSat": s, 'cost': 0, 'pacotes': 0, 'time': 0, "weight":0, "camada": 2}
                        
                        bool_PermitirInsercao = False # Pois é possivel que cliente poderia ser melhor colocado aqui mas nao foi por capacidade

            # Realziar Inserção na rota
            if best_satelite!=-1 and bool_PermitirInsercao:
                currentRoutes[best_satelite]['route'].insert(best_pos[best_satelite], best_r[best_satelite])
                currentRoutes[best_satelite]['cost'] = best_cost[best_satelite]
                currentRoutes[best_satelite]['pacotes'] += self.R[best_r[best_satelite]]["Dropsize"]
                currentRoutes[best_satelite]['time'] += add_time[best_satelite]
                currentRoutes[best_satelite]['weight'] += self.R[best_r[best_satelite]]["weight"]
                currentRoutes[best_satelite]['waitTime'][best_r[best_satelite]] = currentRoutes[best_satelite]['time']
                
                self.S[best_satelite]["Dropsize"]+= self.R[best_r[best_satelite]]["Dropsize"]
                
                if best_address[best_satelite] not in currentRoutes[best_satelite]['address']: 
                    currentRoutes[best_satelite]['address'][best_address[best_satelite]] = {"ships": list(), "costumers": list()}
                currentRoutes[best_satelite]['address'][best_address[best_satelite]]["ships"].append(best_r[best_satelite])
                currentRoutes[best_satelite]['address'][best_address[best_satelite]]["costumers"].append(best_c[best_satelite])
                
                currentRoutes[best_satelite]['ships'].append(best_r[best_satelite])
                
                remessasNaoRoteados.remove(best_r[best_satelite])
                #print(len(remessasNaoRoteados), best_r[best_satelite])
            elif not bool_PermitirInsercao:
                continue
            else:
                print("Chegou um NEGATIVO AQUI")
        
        for s in self.S:
            if len(currentRoutes[s]['route']) > 2:
                rotas.append(currentRoutes[s].copy())#"costumers": {}, 
        self.rotas_2E = rotas
        
        
    def Rotas_PrimeiraCamada(self):
        
        rotas = []
        currentRoutes = {cd: {
                            'route': [cd,cd], 
                            "waitTime": {}, "ships":[], "address": {},
                            "fromSat": cd, "toSat": cd, 'cost': 0, 'pacotes': 0, "weight":0, 'time': 0, "camada":1} 
                            for cd in self.CD} # Inicia uma Rota por satelite
        
        if len(self.S)==0:
            ENTREGAS = self.R
            TempoParada = self.TempoParada
        else:
            ENTREGAS = self.S
            TempoParada = self.TempoParada_1E
        remessasNaoRoteados = list(ENTREGAS.keys())
        
        getAddress = lambda shID: self.R[shID]["aID"] if (shID not in self.S and shID not in self.CD) else shID
        getCustomer = lambda shID: self.R[shID]["cID"] if (shID not in self.S and shID not in self.CD) else shID
        getLatLngCD = lambda sID: (self.CD[sID]["lat"], self.CD[sID]["lng"])
        getLatLngSat = lambda sID: (self.S[sID]["lat"], self.S[sID]["lng"]) if (sID in self.S) else getLatLngCD(sID)
        getLatLng = lambda aID: (self.Enderecos[aID]["lat"], self.Enderecos[aID]["lng"]) if (aID not in self.S and aID not in self.CD) else getLatLngSat(aID)
        
        while len(remessasNaoRoteados)>0:
            
            best_c = {cd: -1 for cd in self.CD}
            best_address = {cd: -1 for cd in self.CD}
            best_r = {cd: -1 for cd in self.CD}
            
            best_cost = {cd: -1 for cd in self.CD}
            best_pos = {cd: -1 for cd in self.CD}
            
            best_satelite = -1
            add_time = {cd: -1 for cd in self.CD} # Tempo da rota inserida
            
            for cd in self.CD:
                rota = currentRoutes[cd]['route'].copy()
                
                pos = len(rota)-1
                
                shID_i = rota[-2]
                aID_i = getAddress(shID_i)
                
                shID_j = rota[-1]
                aID_j = getAddress(shID_j)
                
                for shID in remessasNaoRoteados:
                    cID = getCustomer(shID)
                    aID_R = getAddress(shID)
                
                    # Calc Dist
                    for from_ in [aID_i, aID_j, aID_R]:
                        for to_ in [aID_i, aID_j, aID_R]:
                            from_aID = getLatLngSat(from_) if (from_ in self.S or from_ in self.CD) else getLatLng(from_)
                            to_aID = getLatLngSat(to_) if (to_ in self.S or to_ in self.CD) else getLatLng(to_)
                            
                            if from_ not in self.d1_ij: self.d1_ij[from_] = dict()
                            if to_ not in self.d1_ij[from_]: 
                                self.d1_ij[from_][to_] = geodesic(from_aID, to_aID).km 
                    cost = currentRoutes[cd]['cost'] + self.d1_ij[aID_i][aID_R] + self.d1_ij[aID_R][aID_j] - (self.d1_ij[aID_i][aID_j] if aID_i!=aID_j else 0)
                    
                    add_time[cd] = (self.d1_ij[aID_i][aID_R] + self.d1_ij[aID_R][aID_j] - (self.d1_ij[aID_i][aID_j] if aID_i!=aID_j else 0)) / self.K1["veloc"] # Tempo de viajem
                    # Add tempo de parada se o endereço nao estiver na rota
                    add_time[cd] += self.TempoParada if (aID_R not in currentRoutes[cd]["address"]) else 0
                        
                    if (best_cost[cd] == -1 or best_cost[cd] > cost) and (currentRoutes[cd]['pacotes']+ENTREGAS[shID]["Dropsize"] <= self.K1["capacidade"]):
                        best_cost[cd] = cost
                        best_address[cd] = aID_R
                        best_c[cd] = cID
                        best_r[cd] = shID
                        best_pos[cd] = pos
                        
                        if all([ (cost<=best_cost[cd_] or best_cost[cd_] == -1) for cd_ in self.CD if cd_ != cd]):
                            best_satelite = cd
                        
            
            # Verificar Rotas Completas
            bool_PermitirInsercao = True
            for cd in self.CD:
                if best_cost[cd] == -1:# Sem entrada de clientes disponivel
                    if len(currentRoutes[cd]['route']) > 2:
                        rotas.append(currentRoutes[cd].copy())#"costumers": {}, 
                        currentRoutes[cd] = {'route': [cd,cd], 'waitTime': {}, "ships":[], "address": {},"fromSat": cd, "toSat": cd, 'cost': 0, "weight":0, 'pacotes': 0, 'time': 0, "weight":0, "camada":1}
                        
                        bool_PermitirInsercao = False # Pois é possivel que cliente poderia ser melhor colocado aqui mas nao foi por capacidade

            # Realziar Inserção na rota
            if best_satelite!=-1 and bool_PermitirInsercao:
                currentRoutes[best_satelite]['route'].insert(best_pos[best_satelite], best_r[best_satelite])
                currentRoutes[best_satelite]['cost'] = best_cost[best_satelite]
                currentRoutes[best_satelite]['pacotes'] += ENTREGAS[best_r[best_satelite]]["Dropsize"]
                currentRoutes[best_satelite]['time'] += add_time[best_satelite]
                currentRoutes[best_satelite]['weight'] += self.R[best_r[best_satelite]]["weight"]
                currentRoutes[best_satelite]['waitTime'][best_r[best_satelite]] = currentRoutes[best_satelite]['time']
                
                if best_address[best_satelite] not in currentRoutes[best_satelite]['address']: 
                    currentRoutes[best_satelite]['address'][best_address[best_satelite]] = {"ships": list(), "costumers": list()}
                currentRoutes[best_satelite]['address'][best_address[best_satelite]]["ships"].append(best_r[best_satelite])
                currentRoutes[best_satelite]['address'][best_address[best_satelite]]["costumers"].append(best_c[best_satelite])
                
                currentRoutes[best_satelite]['ships'].append(best_r[best_satelite])
                
                remessasNaoRoteados.remove(best_r[best_satelite])
                #print(len(remessasNaoRoteados), best_r[best_satelite])
            elif not bool_PermitirInsercao:
                continue
            else:
                print("Chegou um NEGATIVO AQUI")
        
        for cd in self.CD:
            if len(currentRoutes[cd]['route']) > 2:
                rotas.append(currentRoutes[cd].copy())#"costumers": {}, 
        self.rotas_1E = rotas