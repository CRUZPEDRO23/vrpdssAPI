
import openrouteservice
from geopy.distance import geodesic

from numba import jit

# Modelo Baseado em Metodo de economias
# Adaptado para 2EC-VRP
# Há Multiplos Satelites, 1 CD
# O CD atende os SATELITES
# Os SATELITES ATENDEM CLIENTES COM AS ENTREGAS DE REMESSAS
# Cada REMESSA está ligada à um cliente, um endereço e um Dropsize
# Duas remessas diferentes podem estar ligadas a um mesmo endereço
# O tempo de entrega de duas ou mais remessas em um mesmo endereço equivale ao tempo de uma única entrega

class interface_Problema:
    def __init__(self, dados):
    
        self.CD = {} # Dados do CD=>{lat, lng}
        
        self.S_ = 0 # Quant. de Satelites
        self.S = {} #Lista de Satelites=> SID: {lat, lng, Capacidade}
        
        self.Enderecos = {} # ID: {lat, lng}
        self.C = []
        
        self.R = {} # Remessas=> ID: {ClienteID, EnderecoID, Dropsize}
        
        self.TempoParada = 0
        self.TempoParada_1E = 0
        
        self.d1_ij = {} #Distancias entre pontos (1ª camada)
        self.d2_ij = {} #Distancias entre pontos (2ª camada)
        
        self.K1 = {} # Tipos de veiculo na segunda camada=> Tipo: {capacidade, veloc}
        self.K2 = {} # Tipos de veiculo na segunda camada=> Tipo: {capacidade, veloc}
        
        self.rotas_1E = list()
        self.rotas_2E = list()
        
        #Cliente para acessar api openrouteservice
        self.client = openrouteservice.Client(key='5b3ce3597851110001cf6248563631cae33f47998bb2579255ee9ee2') # Specify your personal API key
        self.getData(dados)
    def getData(self, dados):
        self.CD = {(f"cd{i}" if "name" not in d else d["name"]): d for i, d in enumerate(dados["CD"])} # Dados do CD=>{lat, lng}
        
        self.S_ = len(dados["satelites"].keys()) # Quant. de Satelites
        self.S = dados["satelites"] #Lista de Satelites=> SID: {lat, lng, Capacidade}
        for s in self.S:
            self.S[s]["Dropsize"] = 0
            
        self.Enderecos = dados["address"] # ID: {lat, lng}
        self.C = dados["costumers"]
        
        self.R = dados["ships"] # Remessas=> ID: {ClienteID, EnderecoID, Dropsize}
        
        self.TempoParada = dados["TempoParada"]
        self.TempoParada_1E = dados["TempoParada_1E"]
        
        self.d1_ij = dados["d1_ij"] #Distancias entre pontos (1ª camada)
        self.d2_ij = dados["d2_ij"] #Distancias entre pontos (2ª camada)
        
        self.K1 = dados["K1"]
        self.K2 = dados["K2"]
    @jit
    def getDistance(self, from_, to_, type_="OSM"):
        
        if from_ == to_:
            return 0
        coords = (from_,to_)
        print(coords)
        if type_ == "OSM":
            routes = self.client.directions(coords)
            return routes["routes"][0]["summary"]["distance"]
        else:
            return geodesic(coords).km
            
            
    def interface_Rotas_SegundaCamada(self, func):
        
        rotas = []#"costumers": {}, 
        currentRoutes = {s: {'route': [s,s], "waitTime":{}, "ships":[], "address": {},"fromSat": s, "toSat": s, 'cost': 0, 'pacotes': 0, 'time': 0, 'camada': 2} for s in self.S} # Inicia uma Rota por satelite
        
        remessasNaoRoteados = list(self.R.keys())
        getAddress = lambda shID: self.R[shID]["aID"] if shID not in self.S else shID
        getCustomer = lambda shID: self.R[shID]["cID"] if shID not in self.S else shID
        getLatLngSat = lambda sID: (self.S[sID]["lat"], self.S[sID]["lng"])
        getLatLng = lambda aID: (self.Enderecos[aID]["lat"], self.Enderecos[aID]["lng"]) if aID not in self.S else getLatLngSat(aID)
        
        while len(remessasNaoRoteados)>0:
            
            best_c = {s: -1 for s in self.S}
            best_address = {s: -1 for s in self.S}
            best_r = {s: -1 for s in self.S}
            
            best_cost = {s: -1 for s in self.S}
            best_pos = {s: -1 for s in self.S}
            
            best_satelite = -1
            add_time = {s: -1 for s in self.S} # Tempo da rota inserida
            
            for shID in remessasNaoRoteados:
                
                cID = getCustomer(shID)
                aID_R = getAddress(shID)
                
                for s in self.S:
                    rota = currentRoutes[s]['route'].copy()
                    for pos in range(1, len(rota)):
                        shID_i = rota[pos-1]
                        shID_j = rota[pos]
                        aID_i = getAddress(shID_i)
                        aID_j = getAddress(shID_j)
                        # Calc Dists
                        for from_ in [aID_i, aID_j, aID_R]:
                            #print(from_)
                            from_aID = getLatLngSat(from_) if from_ in self.S else getLatLng(from_)
                            
                            if from_ not in self.d2_ij: self.d2_ij[from_] = dict()
                            
                            for to_ in [aID_i, aID_j, aID_R]:
                                if to_ not in self.d2_ij[from_]: 
                                    to_aID = getLatLngSat(to_) if to_ in self.S else getLatLng(to_)
                                    
                                    self.d2_ij[from_][to_] = geodesic(from_aID, to_aID).km 
                        
                        cost = currentRoutes[s]['cost'] + self.d2_ij[aID_i][aID_R] + self.d2_ij[aID_R][aID_j] - (self.d2_ij[aID_i][aID_j] if aID_i!=aID_j else 0)
                        
                        if (best_cost[s] == -1 or best_cost[s] > cost) and (currentRoutes[s]['pacotes']+self.R[shID]["Dropsize"] <= self.K2["capacidade"]):
                            best_cost[s] = cost
                            best_address[s] = aID_R
                            best_c[s] = cID
                            best_r[s] = shID
                            best_pos[s] = pos
                            
                            add_time[s] = (self.d2_ij[aID_i][aID_R] + self.d2_ij[aID_R][aID_j] - (self.d2_ij[aID_i][aID_j] if aID_i!=aID_j else 0)) / self.K2["veloc"] # Tempo de viajem
                            # Add tempo de parada se o endereço nao estiver na rota
                            add_time[s] += self.TempoParada if (aID_R not in currentRoutes[s]["address"]) else 0
                            
                            if all([ (cost<=best_cost[s_] or best_cost[s_] == -1) for s_ in self.S if s_ != s]):
                                best_satelite = s
                            
            
            # Verificar Rotas Completas
            bool_PermitirInsercao = True
            for s in self.S:
                if best_cost[s] == -1:# Sem entrada de clientes disponivel
                    if len(currentRoutes[s]['route']) > 2:
                        rotas.append(currentRoutes[s].copy())#"costumers": {}, 
                        currentRoutes[s] = {'route': [s,s], "waitTime": {}, "ships":[], "address": {},"fromSat": s, "toSat": s, 'cost': 0, 'pacotes': 0, 'time': 0, "camada":2}
                        
                        bool_PermitirInsercao = False # Pois é possivel que cliente poderia ser melhor colocado aqui mas nao foi por capacidade

            # Realziar Inserção na rota
            if best_satelite!=-1 and bool_PermitirInsercao:
                currentRoutes[best_satelite]['route'].insert(best_pos[best_satelite], best_r[best_satelite])
                currentRoutes[best_satelite]['cost'] = best_cost[best_satelite]
                currentRoutes[best_satelite]['pacotes'] += self.R[best_r[best_satelite]]["Dropsize"]
                currentRoutes[best_satelite]['time'] += add_time[best_satelite]
                currentRoutes[best_satelite]['waitTime'][best_r[best_satelite]] = add_time[best_satelite]
                
                self.S["best_satelite"]["Dropsize"] += self.R[best_r[best_satelite]]["Dropsize"]
                
                if best_address[best_satelite] not in currentRoutes[best_satelite]['address']: 
                    currentRoutes[best_satelite]['address'][best_address[best_satelite]] = {"ships": list(), "costumers": list()}
                currentRoutes[best_satelite]['address'][best_address[best_satelite]]["ships"].append(best_r[best_satelite])
                currentRoutes[best_satelite]['address'][best_address[best_satelite]]["costumers"].append(best_c[best_satelite])
                
                currentRoutes[best_satelite]['ships'].append(best_r[best_satelite])
                
                remessasNaoRoteados.remove(best_r[best_satelite])
                #print(len(remessasNaoRoteados), best_r[best_satelite])
            elif not bool_PermitirInsercao:
                continue
            else:
                print("Chegou um NEGATIVO AQUI")
        
        for s in self.S:
            if len(currentRoutes[s]['route']) > 2:
                rotas.append(currentRoutes[s].copy())#"costumers": {}, 
        self.rotas_2E = rotas
