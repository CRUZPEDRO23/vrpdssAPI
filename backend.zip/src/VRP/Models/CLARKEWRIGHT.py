
# https://github.com/GIScience/openrouteservice-py

try:
    from interface_Problema import interface_Problema
except Exception:
    from .interface_Problema import interface_Problema


from geopy.distance import geodesic

class CLARKEWRIGHT(interface_Problema):
    def __init____(self, dados):
        
        self.getData(dados)
        
        #self.economias1E = self._Calc_Economias_PrimeiraCamada()
        self.economias2E, self.Valoreconomias2E = self._Calc_Economias_SegundaCamada()
        
    def Rotas_SegundaCamada(self):
        self.economias2E, self.Valoreconomias2E = self._Calc_Economias_SegundaCamada()
        rotas = []
        currentRoutes = {s: {'route': [s,s], "ships":[], "address": {},"fromSat": s, "toSat": s, 'cost': 0, 'pacotes': 0, 'time': 0} for s in self.S} # Inicia uma Rota por satelite
        
        remessasNaoRoteados = list(self.R.keys())
        getAddress = lambda shID: self.R[shID]["aID"] if shID not in self.S else shID
        getCustomer = lambda shID: self.R[shID]["cID"] if shID not in self.S else shID
        getLatLngSat = lambda sID: (self.S[sID]["lat"], self.S[sID]["lng"])
        getLatLng = lambda aID: (self.Enderecos[aID]["lat"], self.Enderecos[aID]["lng"]) if aID not in self.S else getLatLngSat(aID)
        
        while len(remessasNaoRoteados)>0:
            
            best_c = {s: -1 for s in self.S}
            best_address = {s: -1 for s in self.S}
            best_r = {s: -1 for s in self.S}
            
            best_cost = {s: -1 for s in self.S}
            best_pos = {s: -1 for s in self.S}
            
            best_satelite = -1
            add_time = {s: -1 for s in self.S} # Tempo da rota inserida
            
            for s in self.S:
                rota = currentRoutes[s]['route'].copy()
                
                pos = len(rota)-1
                
                shID_i = rota[-2]
                aID_i = getAddress(shID_i)
                
                shID_j = rota[-1]
                aID_j = getAddress(shID_j)
                
                for key in self.economias2E:#Economias organizadas em ordem decrescente
                    if len(key) != 3:
                        continue
                    sat = key[0]
                    i = key[1]
                    j = key[2]
                    
                    if sat != s or i==j:
                        continue
                    elif len(rota)>2 and shID_i != i:
                        continue
                    elif j not in remessasNaoRoteados:
                        continue
                    
                    # Estimar dados
                    if len(rota)>2:
                        shID = j #novo destino
                        cID = getCustomer(shID)
                        aID_R = getAddress(shID)
                
                        # Calc Dist
                        from_aID = getLatLngSat(aID_i) if aID_i in self.S else getLatLng(aID_i)
                        to_aID = getLatLng(aID_R)
                        
                        if aID_i not in self.d2_ij: self.d2_ij[aID_i] = dict()
                        if aID_R not in self.d2_ij[aID_i]: 
                            self.d2_ij[aID_i][aID_R] = geodesic(from_aID, to_aID).km 
                        
                        from_aID = getLatLng(aID_R)
                        to_aID = getLatLngSat(aID_j) if aID_j in self.S else getLatLng(aID_j)
                        
                        if aID_R not in self.d2_ij: self.d2_ij[aID_R] = dict()
                        if aID_j not in self.d2_ij[aID_R]: 
                            self.d2_ij[aID_R][aID_j] = geodesic(from_aID, to_aID).km 
                        
                        from_aID = getLatLngSat(aID_i) if aID_i in self.S else getLatLng(aID_i)
                        to_aID = getLatLngSat(aID_j) if aID_j in self.S else getLatLng(aID_j)
                        
                        if aID_i not in self.d2_ij: self.d2_ij[aID_i] = dict()
                        if aID_j not in self.d2_ij[aID_i]: 
                            self.d2_ij[aID_i][aID_j] = geodesic(from_aID, to_aID).km 
                            
                        
                        cost = currentRoutes[s]['cost'] + self.d2_ij[aID_i][aID_R] + self.d2_ij[aID_R][aID_j] - (self.d2_ij[aID_i][aID_j] if aID_i!=aID_j else 0)
                        
                        if (best_cost[s] == -1 or best_cost[s] > cost) and (currentRoutes[s]['pacotes']+self.R[shID]["Dropsize"] <= self.K2["capacidade"]):
                            best_cost[s] = cost
                            best_address[s] = aID_R
                            best_c[s] = cID
                            best_r[s] = shID
                            best_pos[s] = pos
                            
                            add_time[s] = (self.d2_ij[aID_i][aID_R] + self.d2_ij[aID_R][aID_j] - (self.d2_ij[aID_i][aID_j] if aID_i!=aID_j else 0)) / self.K2["veloc"] # Tempo de viajem
                            # Add tempo de parada se o endereço nao estiver na rota
                            add_time[s] += self.TempoParada if (aID_R not in currentRoutes[s]["address"]) else 0
                            
                            if all([ (cost<=best_cost[s_] or best_cost[s_] == -1) for s_ in self.S if s_ != s]):
                                best_satelite = s
                            break # Avalia candidato de outros satellities
                    
                    elif len(rota)==2 and i in remessasNaoRoteados:
                        shID_1 = i #novo destino
                        cID_1 = getCustomer(shID_1)
                        aID_R_1 = getAddress(shID_1)
                        
                        shID_2 = j #novo destino
                        cID_2 = getCustomer(shID_2)
                        aID_R_2 = getAddress(shID_2)
                        
                        # Calc Dist
                        for from_ in [aID_i, aID_j, aID_R_1, aID_R_2]:
                            for to_ in [aID_i, aID_j, aID_R_1, aID_R_2]:
                                if from_ != to_:
                                    if from_ not in self.d2_ij: self.d2_ij[from_] = dict()
                                    
                                    from_aID = getLatLngSat(from_) if from_ in self.S else getLatLng(from_)
                                    to_aID = getLatLngSat(to_) if to_ in self.S else getLatLng(to_)
                        
                                    if to_ not in self.d2_ij[from_]: 
                                        self.d2_ij[from_][to_] = geodesic(from_aID, to_aID).km 
                        
                        # Tentar Add i e j
                        cost = currentRoutes[s]['cost'] + self.d2_ij[aID_i][aID_R_1] + self.d2_ij[aID_R_1][aID_R_2] + self.d2_ij[aID_R_2][aID_j] - (self.d2_ij[aID_i][aID_j] if aID_i!=aID_j else 0)
                        
                        if (best_cost[s] == -1 or best_cost[s] > cost) and (currentRoutes[s]['pacotes']+self.R[shID_1]["Dropsize"]+self.R[shID_2]["Dropsize"] <= self.K2["capacidade"]):
                            best_cost[s] = cost
                            best_address[s] = [aID_R_1, aID_R_2]
                            best_c[s] = [cID_1, cID_2]
                            best_r[s] = [shID_1, shID_2]
                            best_pos[s] = pos
                            
                            add_time[s] = (self.d2_ij[aID_i][aID_R_1] + self.d2_ij[aID_R_1][aID_R_2] + self.d2_ij[aID_R_2][aID_j] - (self.d2_ij[aID_i][aID_j] if aID_i!=aID_j else 0)) / self.K2["veloc"] # Tempo de viajem
                            # Add tempo de parada se o endereço nao estiver na rota
                            add_time[s] += self.TempoParada if (aID_R_1 not in currentRoutes[s]["address"]) else 0
                            add_time[s] += self.TempoParada if (aID_R_2 not in currentRoutes[s]["address"]) else 0
                            
                            if all([ (cost<=best_cost[s_] or best_cost[s_] == -1) for s_ in self.S if s_ != s]):
                                best_satelite = s
                            break # Avalia candidato de outros satellities
                        # tenta add somente i
                        cost = currentRoutes[s]['cost'] + self.d2_ij[aID_i][aID_R_1] + self.d2_ij[aID_R_1][aID_j] - (self.d2_ij[aID_i][aID_j] if aID_i!=aID_j else 0)
                        
                        if (best_cost[s] == -1 or best_cost[s] > cost) and (currentRoutes[s]['pacotes']+self.R[shID_1]["Dropsize"] <= self.K2["capacidade"]):
                            best_cost[s] = cost
                            best_address[s] = aID_R_1
                            best_c[s] = cID_1
                            best_r[s] = shID_1
                            best_pos[s] = pos
                            
                            add_time[s] = (self.d2_ij[aID_i][aID_R_1] + self.d2_ij[aID_R_1][aID_j] - (self.d2_ij[aID_i][aID_j] if aID_i!=aID_j else 0)) / self.K2["veloc"] # Tempo de viajem
                            # Add tempo de parada se o endereço nao estiver na rota
                            add_time[s] += self.TempoParada if (aID_R_1 not in currentRoutes[s]["address"]) else 0
                            
                            if all([ (cost<=best_cost[s_] or best_cost[s_] == -1) for s_ in self.S if s_ != s]):
                                best_satelite = s
                            break # Avalia candidato de outros satellities
            # Verificar Rotas Completas
            bool_PermitirInsercao = True
            for s in self.S:
                if best_cost[s] == -1:# Sem entrada de clientes disponivel
                    if len(currentRoutes[s]['route']) > 2:
                        rotas.append(currentRoutes[s].copy())#"costumers": {}, 
                        currentRoutes[s] = {'route': [s,s], "ships":[], "address": {},"fromSat": s, "toSat": s, 'cost': 0, 'pacotes': 0, 'time': 0}
                        
                        bool_PermitirInsercao = False # Pois é possivel que cliente poderia ser melhor colocado aqui mas nao foi por capacidade

            # Realziar Inserção na rota
            if best_satelite!=-1 and bool_PermitirInsercao:
                if type(best_r[best_satelite]) != list:
                    
                    currentRoutes[best_satelite]['route'].insert(best_pos[best_satelite], best_r[best_satelite])
                    currentRoutes[best_satelite]['cost'] = best_cost[best_satelite]
                    currentRoutes[best_satelite]['pacotes'] += self.R[best_r[best_satelite]]["Dropsize"]
                    currentRoutes[best_satelite]['time'] += add_time[best_satelite]
                    
                    if best_address[best_satelite] not in currentRoutes[best_satelite]['address']: 
                        currentRoutes[best_satelite]['address'][best_address[best_satelite]] = {"ships": list(), "costumers": list()}
                    currentRoutes[best_satelite]['address'][best_address[best_satelite]]["ships"].append(best_r[best_satelite])
                    currentRoutes[best_satelite]['address'][best_address[best_satelite]]["costumers"].append(best_c[best_satelite])
                    
                    currentRoutes[best_satelite]['ships'].append(best_r[best_satelite])
                    
                    remessasNaoRoteados.remove(best_r[best_satelite])
                    for key_ in self.economias2E:
                        if key_[2] == best_r[best_satelite]:
                            self.economias2E.remove(key_)
                else:
                    print(best_r[best_satelite])
                    for idx, R in enumerate(best_r[best_satelite]):
                        currentRoutes[best_satelite]['route'].insert(best_pos[best_satelite]+idx, R)
                        currentRoutes[best_satelite]['cost'] = best_cost[best_satelite]
                        currentRoutes[best_satelite]['pacotes'] += self.R[R]["Dropsize"]
                        currentRoutes[best_satelite]['time'] += add_time[best_satelite]
                        
                        if best_address[best_satelite][idx] not in currentRoutes[best_satelite]['address']: 
                            currentRoutes[best_satelite]['address'][best_address[best_satelite][idx]] = {"ships": list(), "costumers": list()}
                        currentRoutes[best_satelite]['address'][best_address[best_satelite][idx]]["ships"].append(R)
                        currentRoutes[best_satelite]['address'][best_address[best_satelite][idx]]["costumers"].append(best_c[best_satelite][idx])
                        
                        currentRoutes[best_satelite]['ships'].append(R)
                        
                        remessasNaoRoteados.remove(R)
                    
                    for key_ in self.economias2E:
                        if key_[2] == best_r[best_satelite][0] or key_[2] == best_r[best_satelite][1]:
                            self.economias2E.remove(key_)
                #print(len(remessasNaoRoteados), best_r[best_satelite])
            elif not bool_PermitirInsercao:
                continue
            else:
                print("Chegou um NEGATIVO AQUI")
            print(len(remessasNaoRoteados), len(self.economias2E))
        for s in self.S:
            if len(currentRoutes[s]['route']) > 2:
                rotas.append(currentRoutes[s].copy())#"costumers": {}, 
        self.rotas = rotas
        
        
        
    def _Rotas_SegundaCamada(self):
        
        rotas = []
        currentRoutes = {s: {'route': [s,s], "costumers": {}, "address": {},"fromSat": s, "toSat": s, 'cost': 0, 'pacotes': 0, 'time': 0} for s in self.S} # Inicia uma Rota por satelite
        
        remessasNaoRoteados = list(self.R.keys())
        
        print("INICIANDO ROTA")
        while len(remessasNaoRoteados) > 0:
            tentoaddInSeConseguiu = {s: [False, False] for s in self.S}
            
            for key in self.economias2E:#Economias organizadas em ordem decrescente
                if len(key) != 3:
                    continue
                s = key[0]
                i = key[1]
                j = key[2]
                tentoaddInSeConseguiu[s][0] = True
                # Viajens vao de i para j, logo so considera se j nao roteado
                if j not in remessasNaoRoteados:
                    self.economias2E.remove((s, i, j))
                    continue
                
                elif len(currentRoutes[s]["route"]) == 2 and i in remessasNaoRoteados:
                    if currentRoutes[s]["pacotes"] + self.R[i]["Dropsize"] + self.R[j]["Dropsize"] <= self.K2["capacidade"]:
                        currentRoutes[s]["route"].insert(1, i)
                        currentRoutes[s]["route"].insert(2, j)
                        
                        currentRoutes[s]["pacotes"] += self.R[i]["Dropsize"]
                        currentRoutes[s]["pacotes"] += self.R[j]["Dropsize"]
                        remessasNaoRoteados.remove(i)
                        remessasNaoRoteados.remove(j)
                        
                        tentoaddInSeConseguiu[s][1] = True
                        
                        for key_ in self.economias2E:
                            if key_[2] == i or key_[2] == j:
                                self.economias2E.remove(key_)
                                
                    elif currentRoutes[s]["pacotes"] + self.R[i]["Dropsize"] <= self.K2["capacidade"]:
                        currentRoutes[s]["route"].insert(1, i)
                        
                        currentRoutes[s]["pacotes"] += self.R[i]["Dropsize"]
                        remessasNaoRoteados.remove(i)
                        
                        tentoaddInSeConseguiu[s][1] = True
                        for key_ in self.economias2E:
                            if key_[2] == i:
                                self.economias2E.remove(key_)
                                
                    #self.economias2E.remove((s, i, j)) #Remove nao tem como add i e j nesse satelite

                elif currentRoutes[s]["route"][-2] == i and (currentRoutes[s]["pacotes"] + self.R[j]["Dropsize"] <= self.K2["capacidade"]):
                    currentRoutes[s]["route"].insert(len(currentRoutes[s]["route"]) - 1, j)
                    
                    currentRoutes[s]["pacotes"] += self.R[j]["Dropsize"]
                    remessasNaoRoteados.remove(j)
                    
                    tentoaddInSeConseguiu[s][1] = True
                    
                    for key_ in self.economias2E:
                            if key_[2] == j:
                                self.economias2E.remove(key_)
                    #self.economias2E.remove((s, i, j))
            
            
            if not all([ ( teste[0] == teste[1] )  for teste in tentoaddInSeConseguiu.values() ]):
                # Significa que pelo menos um satelite tentou add cliente mas nao conseguiu por falta de capacidade
                for s in self.S:
                    if tentoaddInSeConseguiu[s][0] and not tentoaddInSeConseguiu[s][1]:
                        rotas.append(currentRoutes[s])
                        currentRoutes[s] = {'route': [s,s], "costumers": {}, "address": {},"fromSat": s, "toSat": s, 'cost': 0, 'pacotes': 0, 'time': 0}
            print(len(remessasNaoRoteados))     
        for s in self.S:
            if len(currentRoutes[s])>2:
                rotas.append(currentRoutes[s])
        self.rotas = rotas
        
    def _Calc_Economias_SegundaCamada(self):
        Pontos = self.R.keys() # Lista de Pontos
        
        economias = dict()
        
        for i in Pontos:
            address_i = self.R[i]["aID"]
            for j in Pontos:
                if i!=j:
                    address_j = self.R[j]["aID"]
                    for s in self.S.keys():
                        
                        if s not in self.d2_ij: self.d2_ij[s] = dict()
                        if address_i not in self.d2_ij: self.d2_ij[address_i] = dict()
                        if address_j not in self.d2_ij: self.d2_ij[address_j] = dict()
                        
                        if address_i not in self.d2_ij[s]: 
                            from_aID = (self.S[s]["lat"], self.S[s]["lng"])
                            to_aID = (self.Enderecos[address_i]["lat"], self.Enderecos[address_i]["lng"])
                            self.d2_ij[s][address_i] = geodesic(from_aID, to_aID).km 
                        
                        if address_j not in self.d2_ij[s]: 
                            from_aID = (self.S[s]["lat"], self.S[s]["lng"])
                            to_aID = (self.Enderecos[address_j]["lat"], self.Enderecos[address_j]["lng"])
                            self.d2_ij[s][address_j] = geodesic(from_aID, to_aID).km 
                        
                        if address_j not in self.d2_ij[address_i]: 
                            from_aID = (self.Enderecos[address_i]["lat"], self.Enderecos[address_i]["lng"])
                            to_aID = (self.Enderecos[address_j]["lat"], self.Enderecos[address_j]["lng"])
                            self.d2_ij[address_i][address_j] = geodesic(from_aID, to_aID).km 
                        if address_i not in self.d2_ij[address_j]: 
                            from_aID = (self.Enderecos[address_j]["lat"], self.Enderecos[address_j]["lng"])
                            to_aID = (self.Enderecos[address_i]["lat"], self.Enderecos[address_i]["lng"])
                            self.d2_ij[address_j][address_i] = geodesic(from_aID, to_aID).km 
                            
                        economias[(s, i, j)] = self.d2_ij[s][address_i] + self.d2_ij[s][address_j] - self.d2_ij[address_i][address_j]
                        
        print("FInalizado Economia")
        pares = list()
        eco = list()
        for k, v in sorted(economias.items(), key=lambda item: item[1]):
            pares.append(k)
            eco.append(v)
        
        return pares, eco