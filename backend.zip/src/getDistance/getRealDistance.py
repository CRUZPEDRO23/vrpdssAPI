
import requests


def getRealDistance(url):
    # example: "https://graphhopper.com/api/1/route?point=-23.529494679800447,-46.779143346973925&point=-23.56028743222669,-46.68386828225753&point=-23.529494679800447,-46.779143346973925&point=-23.52167603127064,-46.70137549891982&instructions=true&type=json&key=e391ea04-e80d-4727-b35c-a66842706a30&vehicle=bike"
    
    r = requests.get(url)

    return r.status_code, r.json()
